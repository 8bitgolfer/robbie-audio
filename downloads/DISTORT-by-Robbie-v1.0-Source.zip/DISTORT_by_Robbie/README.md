# DISTORT by Robbie — VST3 distortion plugin (v1.0)

A real-time, stereo audio effect written in C++ with JUCE 8.0.10. The GUI is dark and minimal, with a transfer-curve visualization and input/output peak meters.

## Features
- Six DSP algorithms: **Soft Clip** (`tanh`), **Hard Clip**, **Tube** (asymmetric saturated curve), **Tape** (soft saturation with simple signal memory), **Foldback**, and **Digital** (10-bit quantization + sample hold).
- Drive (0–30 dB), low-pass Tone (1–18 kHz), Bias (asymmetry in Tube mode), Wet/Dry Mix, and Output (-24 to +12 dB).
- Individual rotary control reset by right-clicking the knob.
- 12 factory presets geared to vocals, 808s, guitars, synths, drums, and subtle bus processing.
- Save/load named user presets (`.rbdistort` XML files) across sessions at `%APPDATA%\Robbie\DISTORT\Presets`.
- Undo and Redo, up to 100 manual edit snapshots per plugin instance, including preset changes. One knob drag is one edit. The undo stack is session-only and does not capture external FL Studio automation edits.
- FL Studio parameter automation, state save/restore in the `.flp`, x64 VST3 effect and optional standalone target.

**Important DSP limitations:** This is a first version. It uses zero-lookahead sample processing and **does not yet implement oversampling**, so strong distortion can produce aliasing. Tape/Tube are simplified coloration models, not physical circuit emulations. Digital mode intentionally produces aliasing. Preset gains may not be loudness matched. This plugin has not been compiled or audio-tested on Windows in this environment.

## Build on Windows (Visual Studio 2026)

1. Install Visual Studio 2026 with **Desktop development with C++**, Windows SDK, CMake, and Git.
2. Extract the ZIP into a short folder path such as `C:\Users\YourName\Desktop\DISTORT_by_Robbie`.
3. Double-click `build-windows.bat`. The first build fetches JUCE from GitHub, so internet is required.
4. After a successful build, look for `build\RobbieDistort_artefacts\Release\VST3\DISTORT.vst3`.
5. Close FL Studio, copy the **whole `DISTORT.vst3` folder** to `C:\Program Files\Common Files\VST3`, reopen FL Studio, then **Options > Manage plugins > Find installed plugins**.
6. In the mixer, open an effect slot and select **DISTORT** (Vendor: Robbie).

If the generator complains that it doesn't match a previous build, delete only the project's `build` folder and rerun the script.

## Using the effect

- Select a saturation mode in the left panel; the curve updates for that mode.
- Raise **Drive** to push into distortion. Use **Tone** to reduce harsh high-frequency content, **Mix** for parallel saturation, and **Output** to manage the level after processing.
- Choose **PRESETS** for factory presets or previously saved user presets.
- Click **SAVE** to save the current settings under your own preset name. Reload them later under **PRESETS > MY PRESETS**.
- Use **UNDO** / **REDO** to step through edits. Right-click a knob and choose **Reset to default**.

## Notes about engineering and host integration

- The plugin parameters use stable IDs; the host can automate them.
- Plugin-instance settings are serialized by JUCE AudioProcessorValueTreeState.
- The user preset directory is per Windows user, not inside the project build folder.
- The audio callback uses preallocated per-channel state, with no per-block heap allocations.
- The sample-rate-dependent filtering is recalculated once per audio block.
- Oversampling, anti-alias filters, robust input/output gain metering, A/B, MIDI and true tape emulation can be developed as later features.
