@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>&1
if errorlevel 1 (
  echo ERROR: CMake not found. Install CMake and add it to PATH.
  pause
  exit /b 1
)
echo.
echo ================================
echo   DISTORT by Robbie - VST3 build
 echo ================================
echo.
echo Generating with Visual Studio 2026...
cmake -S . -B build -G "Visual Studio 18 2026" -A x64
if errorlevel 1 goto fail
echo.
echo Compiling DISTORT VST3 (Release)...
cmake --build build --config Release --target RobbieDistort_VST3 --parallel 4
if errorlevel 1 goto fail
echo.
echo SUCCESS!
echo Look in: build\RobbieDistort_artefacts\Release\VST3\
echo Copy the entire DISTORT.vst3 folder into:
echo C:\Program Files\Common Files\VST3\
pause
exit /b 0
:fail
echo.
echo Build failed. Copy the FIRST ERROR and send it to me.
pause
exit /b 1
