#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

namespace {
constexpr float pi = juce::MathConstants<float>::pi;
struct Preset { const char* name; int mode; float drive, tone, bias, mix, output; };
constexpr Preset presets[] = {
 {"Clean Start",0, 3.f, 72.f, 0.f, 100.f, 0.f},
 {"Warm Tube",2, 9.f, 55.f, 13.f, 75.f, -2.f},
 {"Tape Warmth",3, 7.f, 46.f, 0.f, 72.f, -1.5f},
 {"Soft 808",0, 12.f, 65.f, 0.f, 85.f, -4.f},
 {"Hard 808",1, 21.f, 78.f, 0.f, 100.f, -8.f},
 {"Rage Synth",4, 15.f, 88.f, 7.f, 85.f, -7.f},
 {"Aggressive Vocal",2, 14.f, 70.f, 18.f, 42.f, -3.f},
 {"Dirty Guitar",1, 18.f, 60.f, 0.f, 90.f, -7.f},
 {"Lo-Fi Digital",5, 10.f, 35.f, 0.f, 65.f, -3.f},
 {"Subtle Master",0, 2.f, 75.f, 0.f, 25.f, -0.5f},
 {"Folded Lead",4, 22.f, 85.f, 0.f, 95.f, -9.f},
 {"Crunch Drums",1, 8.f, 80.f, 0.f, 45.f, -3.f}
};
constexpr int presetCount = (int)(sizeof(presets) / sizeof(presets[0]));
}

DistortProcessor::DistortProcessor()
    : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                       .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      state(*this, nullptr, "DISTORT_STATE", createLayout()) {}

juce::AudioProcessorValueTreeState::ParameterLayout DistortProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout p;
    using ID = juce::ParameterID;
    p.add(std::make_unique<juce::AudioParameterChoice>(ID { "mode", 1 }, "Mode",
          juce::StringArray { "Soft Clip", "Hard Clip", "Tube", "Tape", "Foldback", "Digital" }, 0));
    p.add(std::make_unique<juce::AudioParameterFloat>(ID { "drive", 1 }, "Drive", 0.f, 30.f, 3.f));
    p.add(std::make_unique<juce::AudioParameterFloat>(ID { "tone", 1 }, "Tone", 0.f, 100.f, 72.f));
    p.add(std::make_unique<juce::AudioParameterFloat>(ID { "bias", 1 }, "Bias", -50.f, 50.f, 0.f));
    p.add(std::make_unique<juce::AudioParameterFloat>(ID { "mix", 1 }, "Mix", 0.f, 100.f, 100.f));
    p.add(std::make_unique<juce::AudioParameterFloat>(ID { "output", 1 }, "Output Gain", -24.f, 12.f, 0.f));
    p.add(std::make_unique<juce::AudioParameterBool>(ID { "bypass", 1 }, "Bypass", false));
    return p;
}

bool DistortProcessor::isBusesLayoutSupported(const BusesLayout& b) const
{
    const auto& main = b.getMainOutputChannelSet();
    return (main == juce::AudioChannelSet::mono() || main == juce::AudioChannelSet::stereo())
        && b.getMainInputChannelSet() == main;
}
void DistortProcessor::prepareToPlay(double sr, int)
{
    fs = sr > 0 ? sr : 44100.0;
    toneLP.fill(0.f); dcInput.fill(0.f); dcOutput.fill(0.f);
    tapeMemory.fill(0.f); digitalHold.fill(0.f); digitalPhase.fill(0);
    inputMeter.store(0.f); outputMeter.store(0.f);
}

float DistortProcessor::shape(float v, int m, float b, float& tape)
{
    switch (m)
    {
        case 1: return juce::jlimit(-1.f, 1.f, v);
        case 2: {
            // Biased, asymmetric tube-style transfer. High-pass DC removal follows.
            const float f = std::tanh(v + b) - std::tanh(b);
            return juce::jlimit(-1.5f, 1.5f, f);
        }
        case 3: {
            // Magnetic-like saturation with short-term memory (not a physical tape model).
            tape = 0.985f * tape + 0.015f * v;
            return (2.f / pi) * std::atan(1.7f * v + 0.3f * tape);
        }
        case 4: {
            // Foldback wrapping into [-1, 1].
            float x = std::fmod(v + 1.f, 4.f);
            if (x < 0.f) x += 4.f;
            return x <= 2.f ? x - 1.f : 3.f - x;
        }
        case 5: return juce::jlimit(-1.f, 1.f, v);
        default: return std::tanh(v);
    }
}

void DistortProcessor::processBlock(juce::AudioBuffer<float>& audio, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals guard;
    const int channels = juce::jmin(audio.getNumChannels(), 2);
    if (channels == 0) return;
    const int len = audio.getNumSamples();
    const int m = juce::jlimit(0, modeCount - 1, (int)state.getRawParameterValue("mode")->load());
    const float driveDb = state.getRawParameterValue("drive")->load();
    const float tone = state.getRawParameterValue("tone")->load() * 0.01f;
    const float bias = state.getRawParameterValue("bias")->load() * 0.01f;
    const float wet = state.getRawParameterValue("mix")->load() * 0.01f;
    const float out = juce::Decibels::decibelsToGain(state.getRawParameterValue("output")->load());
    const bool by = state.getRawParameterValue("bypass")->load() > 0.5f;
    const float driveLinear = juce::Decibels::decibelsToGain(driveDb);
    const float fc = 1000.f * std::pow(18.f, tone); // 1k to 18k low-pass tone
    const float alpha = std::exp(-2.f * pi * fc / (float)fs);
    const float dcR = std::exp(-2.f * pi * 15.f / (float)fs);
    float peakIn = 0.f, peakOut = 0.f;
    for (int ch = 0; ch < channels; ++ch)
    {
        auto* x = audio.getWritePointer(ch);
        for (int i = 0; i < len; ++i)
        {
            const float dry = x[i];
            peakIn = juce::jmax(peakIn, std::abs(dry));
            if (by) { peakOut = juce::jmax(peakOut, std::abs(dry)); continue; }
            const float driven = dry * driveLinear;
            float shaped;
            if (m == 5)
            {
                // A little 10-bit quantization plus sample-rate reduction.
                if (digitalPhase[(size_t)ch]++ >= 3)
                {
                    digitalPhase[(size_t)ch] = 0;
                    digitalHold[(size_t)ch] = std::round(juce::jlimit(-1.f, 1.f, driven) * 511.f) / 511.f;
                }
                shaped = digitalHold[(size_t)ch];
            }
            else shaped = shape(driven, m, bias, tapeMemory[(size_t)ch]);
            toneLP[(size_t)ch] = (1.f - alpha) * shaped + alpha * toneLP[(size_t)ch];
            const float filtered = toneLP[(size_t)ch];
            // Remove DC introduced by the asymmetry and saturation.
            const float dc = filtered - dcInput[(size_t)ch] + dcR * dcOutput[(size_t)ch];
            dcInput[(size_t)ch] = filtered;
            dcOutput[(size_t)ch] = dc;
            const float result = (dry * (1.f - wet) + dc * wet) * out;
            x[i] = result;
            peakOut = juce::jmax(peakOut, std::abs(result));
        }
    }
    // Single-writer audio thread; relaxed UI meters do not affect DSP.
    inputMeter.store(juce::jmax(peakIn, inputMeter.load(std::memory_order_relaxed) * 0.85f), std::memory_order_relaxed);
    outputMeter.store(juce::jmax(peakOut, outputMeter.load(std::memory_order_relaxed) * 0.85f), std::memory_order_relaxed);
}

float DistortProcessor::getParameterReal(ParamIndex i) const
{ return state.getRawParameterValue(ids[(size_t)i])->load(); }
void DistortProcessor::setParameterReal(ParamIndex i, float real)
{
    if (auto* p = state.getParameter(ids[(size_t)i]))
    {
        p->beginChangeGesture();
        p->setValueNotifyingHost(p->convertTo0to1(real));
        p->endChangeGesture();
    }
}

void DistortProcessor::checkpoint()
{
    if (restoreInProgress) return;
    undoStates.push_back(state.copyState());
    if (undoStates.size() > 100) undoStates.erase(undoStates.begin());
    redoStates.clear();
}
void DistortProcessor::restore(const juce::ValueTree& tree)
{
    restoreInProgress = true;
    // Notify FL Studio parameter listeners through parameter APIs, preserving IDs and automation.
    for (int i = 0; i < numParams; ++i)
    {
        const auto val = tree.getChildWithProperty("id", juce::var(ids[(size_t)i]));
        if (val.isValid() && val.hasProperty("value"))
            setParameterReal((ParamIndex)i, (float)val.getProperty("value"));
    }
    restoreInProgress = false;
}
void DistortProcessor::undoEdit()
{
    if (undoStates.empty()) return;
    redoStates.push_back(state.copyState());
    auto before = undoStates.back(); undoStates.pop_back(); restore(before);
}
void DistortProcessor::redoEdit()
{
    if (redoStates.empty()) return;
    undoStates.push_back(state.copyState());
    auto after = redoStates.back(); redoStates.pop_back(); restore(after);
}

juce::StringArray DistortProcessor::factoryNames()
{
    juce::StringArray result;
    for (const auto& p : presets) result.add(p.name);
    return result;
}
void DistortProcessor::applyFactory(int idx)
{
    if (!juce::isPositiveAndBelow(idx, presetCount)) return;
    checkpoint();
    const auto& p = presets[idx];
    setParameterReal(mode, (float)p.mode);
    setParameterReal(drive, p.drive); setParameterReal(tone, p.tone);
    setParameterReal(bias, p.bias); setParameterReal(mix, p.mix);
    setParameterReal(output, p.output); setParameterReal(bypass, 0.f);
}
juce::File DistortProcessor::userPresetDirectory() const
{
    auto dir = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
                    .getChildFile("Robbie").getChildFile("DISTORT").getChildFile("Presets");
    return dir;
}
juce::StringArray DistortProcessor::userPresetNames() const
{
    juce::StringArray names;
    auto list = userPresetDirectory().findChildFiles(juce::File::findFiles, false, "*.rbdistort");
    for (const auto& file : list) names.add(file.getFileNameWithoutExtension());
    names.sort(true);
    return names;
}
bool DistortProcessor::saveUserPreset(const juce::String& name, juce::String& error) const
{
    const auto safe = juce::File::createLegalFileName(name.trim());
    if (safe.isEmpty()) { error = "Enter a preset name."; return false; }
    const auto dir = userPresetDirectory();
    if (!dir.isDirectory() && !dir.createDirectory()) { error = "Cannot create preset folder."; return false; }
    auto file = dir.getChildFile(safe).withFileExtension(".rbdistort");
    auto xml = state.copyState().createXml();
    if (xml == nullptr || !xml->writeTo(file)) { error = "Cannot write preset file."; return false; }
    return true;
}
bool DistortProcessor::loadUserPreset(const juce::String& name, juce::String& error)
{
    auto file = userPresetDirectory().getChildFile(juce::File::createLegalFileName(name)).withFileExtension(".rbdistort");
    if (!file.existsAsFile()) { error = "Preset not found."; return false; }
    auto xml = juce::XmlDocument::parse(file);
    if (xml == nullptr) { error = "Preset is not valid XML."; return false; }
    auto tree = juce::ValueTree::fromXml(*xml);
    if (!tree.isValid() || !tree.hasType(state.state.getType())) { error = "Invalid DISTORT preset."; return false; }
    checkpoint(); restore(tree);
    return true;
}

void DistortProcessor::getStateInformation(juce::MemoryBlock& data)
{
    if (auto xml = state.copyState().createXml()) copyXmlToBinary(*xml, data);
}
void DistortProcessor::setStateInformation(const void* ptr, int size)
{
    if (auto xml = getXmlFromBinary(ptr, size))
        if (xml->hasTagName(state.state.getType()))
        {
            state.replaceState(juce::ValueTree::fromXml(*xml));
            undoStates.clear(); redoStates.clear();
        }
}
juce::AudioProcessorEditor* DistortProcessor::createEditor() { return new DistortEditor(*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new DistortProcessor(); }
