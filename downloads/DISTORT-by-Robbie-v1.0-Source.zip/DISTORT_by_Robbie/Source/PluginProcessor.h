#pragma once
#include <JuceHeader.h>
#include <array>
#include <atomic>
#include <vector>

class DistortProcessor final : public juce::AudioProcessor
{
public:
    enum ParamIndex { mode, drive, tone, bias, mix, output, bypass, numParams };
    static constexpr int modeCount = 6;
    DistortProcessor();
    ~DistortProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "DISTORT"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    juce::AudioProcessorValueTreeState state;
    static constexpr std::array<const char*, numParams> ids = {"mode", "drive", "tone", "bias", "mix", "output", "bypass"};
    static constexpr std::array<const char*, modeCount> modeNames = {"Soft Clip", "Hard Clip", "Tube", "Tape", "Foldback", "Digital"};
    void setParameterReal(ParamIndex index, float value);
    float getParameterReal(ParamIndex index) const;

    void checkpoint();
    void undoEdit();
    void redoEdit();
    bool canUndo() const { return !undoStates.empty(); }
    bool canRedo() const { return !redoStates.empty(); }
    void applyFactory(int preset);
    static juce::StringArray factoryNames();
    juce::File userPresetDirectory() const;
    juce::StringArray userPresetNames() const;
    bool saveUserPreset(const juce::String& name, juce::String& error) const;
    bool loadUserPreset(const juce::String& name, juce::String& error);

    std::atomic<float> inputMeter { 0.f }, outputMeter { 0.f };
    static float shape(float v, int mode, float bias, float& tapeState);

private:
    double fs = 44100.0;
    std::array<float, 2> toneLP {}, dcInput {}, dcOutput {}, tapeMemory {}, digitalHold {};
    std::array<int, 2> digitalPhase {};
    std::vector<juce::ValueTree> undoStates, redoStates;
    bool restoreInProgress = false;
    void restore(const juce::ValueTree&);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DistortProcessor)
};
