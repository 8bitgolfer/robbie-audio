#pragma once
#include "PluginProcessor.h"
#include <JuceHeader.h>
#include <array>

class DistortEditor final : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit DistortEditor(DistortProcessor&);
    ~DistortEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    struct Skin : juce::LookAndFeel_V4
    {
        void drawRotarySlider(juce::Graphics&, int, int, int, int, float, float, float, juce::Slider&) override;
    } skin;
    struct ResetSlider : juce::Slider
    {
        std::function<void()> reset;
        void mouseDown(const juce::MouseEvent& e) override
        {
            if (!e.mods.isPopupMenu()) { juce::Slider::mouseDown(e); return; }
            juce::PopupMenu popup;
            popup.addItem(1, "Reset to default");
            juce::Component::SafePointer<ResetSlider> safe(this);
            popup.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(this), [safe](int result)
            {
                if (safe != nullptr && result == 1 && safe->reset) safe->reset();
            });
        }
    };
    DistortProcessor& processor;
    juce::ComboBox mode;
    ResetSlider drive, tone, bias, mix, output;
    juce::TextButton presetButton { "PRESETS  v" }, saveButton { "SAVE" }, undoButton { "UNDO" },
                     redoButton { "REDO" }, bypassButton { "BYPASS" };
    std::array<juce::Label, 5> labels;
    std::array<juce::Slider*, 5> controls;
    std::array<DistortProcessor::ParamIndex, 5> controlParams {
        DistortProcessor::drive, DistortProcessor::tone, DistortProcessor::bias,
        DistortProcessor::mix, DistortProcessor::output };
    std::array<bool, 5> dragging {};
    juce::Rectangle<float> transferArea, inMeterArea, outMeterArea;
    juce::String currentPreset { "Clean Start" };
    void timerCallback() override;
    void refresh();
    void showPresets();
    void promptSave();
    void showError(const juce::String& title, const juce::String& detail);
    static juce::Colour bg, surface, line, text, muted, orange;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(DistortEditor)
};
