#include "PluginEditor.h"
#include <cmath>

juce::Colour DistortEditor::bg (0xff101216);
juce::Colour DistortEditor::surface (0xff191c22);
juce::Colour DistortEditor::line (0xff313641);
juce::Colour DistortEditor::text (0xfff0f1f3);
juce::Colour DistortEditor::muted (0xff8c94a1);
juce::Colour DistortEditor::orange (0xffff945d);

void DistortEditor::Skin::drawRotarySlider(juce::Graphics& g, int x, int y, int w, int h,
        float position, float startAngle, float endAngle, juce::Slider&)
{
    const float r = juce::jmin(w, h) * 0.33f;
    const float cx = x + w * 0.5f, cy = y + h * 0.45f;
    const auto outer = juce::Rectangle<float>(cx-r, cy-r, r*2.f, r*2.f);
    g.setColour(juce::Colour(0xff292e37)); g.fillEllipse(outer);
    g.setColour(juce::Colour(0xff464e5b)); g.drawEllipse(outer, 1.4f);
    auto track = outer.reduced(-6.f);
    juce::Path rail;
    rail.addCentredArc(cx, cy, track.getWidth()*0.5f, track.getHeight()*0.5f,
                       0.f, startAngle, endAngle, true);
    g.setColour(juce::Colour(0xff444b56));
    g.strokePath(rail, juce::PathStrokeType(3.f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    juce::Path active;
    active.addCentredArc(cx, cy, track.getWidth()*0.5f, track.getHeight()*0.5f,
                         0.f, startAngle, startAngle + (endAngle - startAngle) * position, true);
    g.setColour(juce::Colour(0xffff945d));
    g.strokePath(active, juce::PathStrokeType(3.f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    const float a = startAngle + (endAngle - startAngle) * position;
    g.setColour(juce::Colours::white);
    g.drawLine(cx + std::sin(a) * (r * 0.32f), cy - std::cos(a) * (r * 0.32f),
               cx + std::sin(a) * (r * 0.78f), cy - std::cos(a) * (r * 0.78f), 2.2f);
}

DistortEditor::DistortEditor(DistortProcessor& p)
    : AudioProcessorEditor(&p), processor(p), controls { &drive, &tone, &bias, &mix, &output }
{
    setSize(880, 540);
    setResizable(true, true);
    setResizeLimits(790, 510, 1300, 760);
    setLookAndFeel(&skin);

    mode.addItemList(juce::StringArray { "Soft Clip", "Hard Clip", "Tube", "Tape", "Foldback", "Digital" }, 1);
    addAndMakeVisible(mode);
    mode.setColour(juce::ComboBox::backgroundColourId, surface);
    mode.setColour(juce::ComboBox::outlineColourId, line);
    mode.setColour(juce::ComboBox::textColourId, text);
    mode.setColour(juce::ComboBox::arrowColourId, orange);
    mode.onChange = [this]
    {
        if (mode.getSelectedId() < 1) return;
        processor.checkpoint();
        processor.setParameterReal(DistortProcessor::mode, (float)(mode.getSelectedId()-1));
        currentPreset = "Modified"; repaint();
    };

    const char* labelNames[5] = { "DRIVE", "TONE", "BIAS", "MIX", "OUTPUT" };
    const double low[5] = { 0, 0, -50, 0, -24 };
    const double high[5] = { 30, 100, 50, 100, 12 };
    const char* suffix[5] = { " dB", " %", " %", " %", " dB" };
    for (int i = 0; i < 5; ++i)
    {
        auto* s = controls[(size_t)i];
        addAndMakeVisible(*s);
        s->setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        s->setTextBoxStyle(juce::Slider::TextBoxBelow, false, 86, 22);
        s->setRange(low[i], high[i], 0.1);
        s->setTextValueSuffix(suffix[i]);
        s->setColour(juce::Slider::textBoxTextColourId, text);
        s->setColour(juce::Slider::textBoxBackgroundColourId, surface);
        s->setColour(juce::Slider::textBoxOutlineColourId, line);
        addAndMakeVisible(labels[(size_t)i]);
        auto& l = labels[(size_t)i];
        l.setText(labelNames[i], juce::dontSendNotification);
        l.setFont(juce::FontOptions(11.f, juce::Font::bold));
        l.setJustificationType(juce::Justification::centred);
        l.setColour(juce::Label::textColourId, muted);
        static_cast<ResetSlider*>(s)->reset = [this, i]
        {
            processor.checkpoint();
            const auto index = controlParams[(size_t)i];
            if (auto* param = processor.state.getParameter(DistortProcessor::ids[(size_t)index]))
            {
                param->beginChangeGesture();
                param->setValueNotifyingHost(param->getDefaultValue());
                param->endChangeGesture();
            }
            currentPreset = "Modified"; refresh();
        };
        s->onDragStart = [this, i] { dragging[(size_t)i] = true; processor.checkpoint(); };
        s->onDragEnd = [this, i] { dragging[(size_t)i] = false; };
        s->onValueChange = [this, i]
        {
            if (!dragging[(size_t)i]) processor.checkpoint();
            processor.setParameterReal(controlParams[(size_t)i], (float)controls[(size_t)i]->getValue());
            currentPreset = "Modified";
            repaint();
        };
    }
    for (auto* b : { &presetButton, &saveButton, &undoButton, &redoButton, &bypassButton })
    {
        addAndMakeVisible(*b);
        b->setColour(juce::TextButton::buttonColourId, surface);
        b->setColour(juce::TextButton::textColourOffId, text);
    }
    presetButton.onClick = [this] { showPresets(); };
    saveButton.onClick = [this] { promptSave(); };
    undoButton.onClick = [this] { processor.undoEdit(); currentPreset = "Modified"; refresh(); };
    redoButton.onClick = [this] { processor.redoEdit(); currentPreset = "Modified"; refresh(); };
    bypassButton.onClick = [this]
    {
        processor.checkpoint();
        processor.setParameterReal(DistortProcessor::bypass, processor.getParameterReal(DistortProcessor::bypass) > .5f ? 0.f : 1.f);
        currentPreset = "Modified"; refresh();
    };
    refresh();
    startTimerHz(25);
}
DistortEditor::~DistortEditor() { stopTimer(); setLookAndFeel(nullptr); }
void DistortEditor::refresh()
{
    mode.setSelectedId(1 + (int)processor.getParameterReal(DistortProcessor::mode), juce::dontSendNotification);
    for (int i=0; i<5; ++i)
        if (!dragging[(size_t)i]) controls[(size_t)i]->setValue(processor.getParameterReal(controlParams[(size_t)i]), juce::dontSendNotification);
    const bool by = processor.getParameterReal(DistortProcessor::bypass) > .5f;
    bypassButton.setButtonText(by ? "BYPASSED" : "BYPASS");
    bypassButton.setColour(juce::TextButton::buttonColourId, by ? juce::Colour(0xff6a3d34) : surface);
    undoButton.setEnabled(processor.canUndo());
    redoButton.setEnabled(processor.canRedo());
    repaint();
}
void DistortEditor::showPresets()
{
    juce::PopupMenu menu;
    menu.addSectionHeader("FACTORY PRESETS");
    const auto factory = DistortProcessor::factoryNames();
    for (int i=0; i<factory.size(); ++i) menu.addItem(100+i, factory[i]);
    const auto user = processor.userPresetNames();
    if (!user.isEmpty())
    {
        menu.addSeparator(); menu.addSectionHeader("MY PRESETS");
        for (int i=0; i<user.size(); ++i) menu.addItem(1000+i, user[i]);
    }
    juce::Component::SafePointer<DistortEditor> safe(this);
    menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&presetButton),
        [safe, factory, user](int result)
        {
            if (safe == nullptr) return;
            if (result >= 100 && result < 100 + factory.size())
            {
                safe->processor.applyFactory(result - 100);
                safe->currentPreset = factory[result-100];
                safe->refresh();
            }
            else if (result >= 1000 && result < 1000 + user.size())
            {
                juce::String error;
                if (safe->processor.loadUserPreset(user[result - 1000], error))
                { safe->currentPreset = user[result-1000]; safe->refresh(); }
                else safe->showError("Preset load failed", error);
            }
        });
}
void DistortEditor::showError(const juce::String& title, const juce::String& message)
{
    juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon, title, message);
}
void DistortEditor::promptSave()
{
    auto dialog = std::make_unique<juce::AlertWindow>("Save preset", "Save DISTORT settings to your presets folder.", juce::MessageBoxIconType::NoIcon);
    dialog->addTextEditor("name", currentPreset == "Modified" ? "My Distortion" : currentPreset, "Preset name:");
    dialog->addButton("Save", 1, juce::KeyPress(juce::KeyPress::returnKey));
    dialog->addButton("Cancel", 0, juce::KeyPress(juce::KeyPress::escapeKey));
    juce::Component::SafePointer<DistortEditor> safe(this);
    auto* raw = dialog.release();
    raw->enterModalState(true, juce::ModalCallbackFunction::create([safe, raw](int result)
    {
        if (safe != nullptr && result == 1)
        {
            const auto presetName = raw->getTextEditorContents("name").trim();
            juce::String error;
            if (safe->processor.saveUserPreset(presetName, error))
            { safe->currentPreset = presetName; safe->refresh(); }
            else safe->showError("Save failed", error);
        }
    }), true);
}
void DistortEditor::resized()
{
    const int w = getWidth(), h = getHeight();
    presetButton.setBounds(w - 380, 22, 142, 32);
    saveButton.setBounds(w - 228, 22, 70, 32);
    undoButton.setBounds(w - 150, 22, 64, 32);
    redoButton.setBounds(w - 78, 22, 64, 32);
    mode.setBounds(32, 120, 190, 34);
    bypassButton.setBounds(w - 151, 115, 118, 34);
    transferArea = { 264.f, 108.f, (float)w - 300.f, (float)h - 275.f };
    inMeterArea = { 274.f, (float)h - 145.f, (float)w - 310.f, 7.f };
    outMeterArea = { 274.f, (float)h - 116.f, (float)w - 310.f, 7.f };
    const int knobsY = h - 94;
    const int totalWidth = w - 56;
    const int each = totalWidth / 5;
    for (int i=0; i<5; ++i)
    {
        labels[(size_t)i].setBounds(28+i*each, knobsY-6, each, 17);
        controls[(size_t)i]->setBounds(28+i*each, knobsY+10, each, 88);
    }
}
void DistortEditor::paint(juce::Graphics& g)
{
    g.fillAll(bg);
    g.setColour(juce::Colour(0xff181b20));
    g.fillRect(0, 0, getWidth(), 78);
    g.setColour(line); g.drawHorizontalLine(78, 0.f, (float)getWidth());
    g.setColour(text); g.setFont(juce::FontOptions(28.f, juce::Font::bold));
    g.drawText("DISTORT", 28, 18, 205, 39, juce::Justification::centredLeft);
    g.setColour(orange); g.fillRoundedRectangle(218.f, 28.f, 5.f, 27.f, 2.f);
    g.setColour(muted); g.setFont(juce::FontOptions(11.f));
    g.drawText("by Robbie", 239, 30, 105, 22, juce::Justification::centredLeft);

    g.setColour(surface);
    g.fillRoundedRectangle(22.f, 98.f, 222.f, (float)getHeight() - 263.f, 9.f);
    g.setColour(line); g.drawRoundedRectangle(22.f, 98.f, 222.f, (float)getHeight()-263.f, 9.f, 1.f);
    g.setColour(muted); g.setFont(juce::FontOptions(11.f, juce::Font::bold));
    g.drawText("SATURATION MODE", 34, 102, 182, 18, juce::Justification::centredLeft);
    g.drawText("CURRENT PRESET", 34, 178, 182, 20, juce::Justification::centredLeft);
    g.setColour(text); g.setFont(juce::FontOptions(16.f));
    g.drawFittedText(currentPreset, 34, 202, 183, 35, juce::Justification::centredLeft, 2);
    g.setColour(muted); g.setFont(juce::FontOptions(11.f));
    g.drawFittedText("6 modes  /  stereo  /  wet-dry", 34, 257, 183, 22, juce::Justification::centredLeft, 1);
    g.drawFittedText("Right-click to reset a knob", 34, 287, 186, 20, juce::Justification::centredLeft, 1);
    g.drawFittedText("Factory + saved presets", 34, 310, 186, 20, juce::Justification::centredLeft, 1);

    g.setColour(surface); g.fillRoundedRectangle(transferArea, 9.f);
    g.setColour(line); g.drawRoundedRectangle(transferArea, 9.f, 1.f);
    g.setColour(muted); g.setFont(juce::FontOptions(10.f, juce::Font::bold));
    g.drawText("TRANSFER CURVE", (int)transferArea.getX()+14, (int)transferArea.getY()+8, 180, 18, juce::Justification::centredLeft);
    g.drawText("IN", (int)transferArea.getRight()-34, (int)transferArea.getBottom()-23, 28, 15, juce::Justification::centredLeft);
    g.drawText("OUT", (int)transferArea.getX()+8, (int)transferArea.getY()+30, 38, 15, juce::Justification::centredLeft);
    auto inner = transferArea.reduced(32.f, 31.f);
    g.setColour(line.withAlpha(.55f));
    for (int i=0;i<=4;++i)
    {
        const float x = inner.getX()+inner.getWidth()*i/4.f;
        const float y = inner.getY()+inner.getHeight()*i/4.f;
        g.drawVerticalLine((int)x, inner.getY(), inner.getBottom());
        g.drawHorizontalLine((int)y, inner.getX(), inner.getRight());
    }
    g.setColour(juce::Colour(0xff66717f));
    g.drawLine(inner.getX(), inner.getBottom(), inner.getRight(), inner.getY(), 1.f);
    juce::Path curve;
    int m = (int)processor.getParameterReal(DistortProcessor::mode);
    const float driveAmt = juce::Decibels::decibelsToGain(processor.getParameterReal(DistortProcessor::drive));
    const float biasAmt = processor.getParameterReal(DistortProcessor::bias)*.01f;
    float tapeState = 0.f;
    for (int i=0; i<=256; ++i)
    {
        float x = -1.f + i / 128.f;
        float y = DistortProcessor::shape(x*driveAmt, m, biasAmt, tapeState);
        if (m == 5) y = std::round(juce::jlimit(-1.f, 1.f, x * driveAmt)*511.f)/511.f;
        y = juce::jlimit(-1.f,1.f,y);
        float px = inner.getX() + i/256.f*inner.getWidth();
        float py = inner.getCentreY() - y*inner.getHeight()*.5f;
        if (i == 0) curve.startNewSubPath(px,py); else curve.lineTo(px,py);
    }
    g.setColour(orange.withAlpha(0.10f));
    g.strokePath(curve, juce::PathStrokeType(7.f));
    g.setColour(orange); g.strokePath(curve, juce::PathStrokeType(2.3f));

    const float in = processor.inputMeter.load();
    const float out = processor.outputMeter.load();
    auto drawMeter = [&g](juce::Rectangle<float> r, float level)
    {
        g.setColour(juce::Colour(0xff2b3039)); g.fillRoundedRectangle(r, 2.f);
        const float db = juce::Decibels::gainToDecibels(level, -60.f);
        const float fraction = juce::jlimit(0.f,1.f,(db + 60.f)/66.f);
        r.setWidth(r.getWidth()*fraction);
        g.setColour(level >= 1.f ? juce::Colour(0xffff685c) : juce::Colour(0xffff945d));
        g.fillRoundedRectangle(r,2.f);
    };
    g.setColour(muted); g.setFont(juce::FontOptions(10.f, juce::Font::bold));
    g.drawText("INPUT", (int)inMeterArea.getX(), (int)inMeterArea.getY()-17, 72, 15, juce::Justification::centredLeft);
    g.drawText("OUTPUT", (int)outMeterArea.getX(), (int)outMeterArea.getY()-17, 72, 15, juce::Justification::centredLeft);
    drawMeter(inMeterArea, in); drawMeter(outMeterArea, out);

    g.setColour(surface); g.fillRect(0, getHeight()-105, getWidth(), 105);
    g.setColour(line); g.drawHorizontalLine(getHeight()-105, 0.f, (float)getWidth());
}
void DistortEditor::timerCallback() { refresh(); }
