#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"
#include <array>

class NovaEQAudioProcessorEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit NovaEQAudioProcessorEditor(NovaEQAudioProcessor&);
    ~NovaEQAudioProcessorEditor() override = default;
    void paint(juce::Graphics&) override;
    void resized() override;
    bool keyPressed(const juce::KeyPress&) override;
    void mouseDown(const juce::MouseEvent&) override;
    void mouseDrag(const juce::MouseEvent&) override;
    void mouseUp(const juce::MouseEvent&) override;
    void mouseDoubleClick(const juce::MouseEvent&) override;
    void mouseWheelMove(const juce::MouseEvent&, const juce::MouseWheelDetails&) override;
private:
    NovaEQAudioProcessor& processor;
    juce::Rectangle<float> graph;
    int selected = 3;
    bool dragging = false;
    juce::Slider frequency, gain, quality, output, mix;
    juce::ComboBox filterType;
    juce::TextButton enabled { "ON" }, bypass { "BYPASS" }, reset { "RESET ALL" };
    juce::TextButton presetButton { "PRESETS" }, saveButton { "SAVE" }, undoButton { "UNDO" }, redoButton { "REDO" };
    juce::String activePreset = "Default";
    bool editActive = false;
    NovaEQAudioProcessor::Snapshot editBefore {};
    std::unique_ptr<juce::FileChooser> presetChooser;
    void beginEdit();
    void finishEdit();
    void runUndo();
    void runRedo();
    void applyFactoryPreset(int index);
    void showPresetsMenu();
    void savePresetDialog();
    void importPresetDialog();
    juce::File presetDirectory() const;
    bool savePresetToFile(const juce::File& file);
    bool loadPresetFromFile(const juce::File& file);
    void performTrackedAction(const std::function<void()>& fn);

    juce::Label freqLabel, gainLabel, qLabel, typeLabel, outLabel, mixLabel;
    std::array<float, NovaEQAudioProcessor::fftSize / 2> spectrum {};
    std::array<float, NovaEQAudioProcessor::fftSize / 2> smoothSpectrum {};
    std::array<juce::Colour, 8> colours { juce::Colour(0xfff59c64), juce::Colour(0xffe8bf65), juce::Colour(0xffa7d86d), juce::Colour(0xff66d5ba), juce::Colour(0xff6dbbfc), juce::Colour(0xffb093ff), juce::Colour(0xfff18fc5), juce::Colour(0xffff7489) };
    void timerCallback() override;
    void selectBand(int band);
    void syncControls();
    void writeParam(const juce::String& id, float realValue);
    void resetAll();
    void resetBand(int band);
    void showBandMenu(int band);
    static float freqToNorm(float f);
    static float normToFreq(float norm);
    float xForFreq(float hz) const;
    float yForGain(float db) const;
    float freqForX(float x) const;
    float gainForY(float y) const;
    void paintGraph(juce::Graphics&);
    void setupKnob(juce::Slider&, juce::Label&, const juce::String&);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(NovaEQAudioProcessorEditor)
};
