#pragma once
#include <JuceHeader.h>
#include <array>
#include <atomic>

class NovaEQAudioProcessor : public juce::AudioProcessor
{
public:
    static constexpr int bandCount = 8;
    static constexpr int fftOrder = 11;
    static constexpr int fftSize = 1 << fftOrder;
    using Coeff = juce::dsp::IIR::Coefficients<float>;
    NovaEQAudioProcessor();
    ~NovaEQAudioProcessor() override = default;
    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "EQ"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    juce::AudioProcessorValueTreeState parameters;
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();
    static juce::String id(int band, const char* suffix) { return "b" + juce::String(band) + suffix; }
    static std::array<float, 5> readBand(const NovaEQAudioProcessor&, int band);
    static double magnitudeAt(float freq, double sr, const std::array<float, 5>& band);
    bool fetchSpectrum(std::array<float, fftSize / 2>& destination);
    static constexpr int parameterCount = bandCount * 5 + 3;
    using Snapshot = std::array<float, parameterCount>;
    Snapshot captureSnapshot() const;
    void applySnapshot(const Snapshot&);
    void recordEdit(const Snapshot& before);
    bool undoEdit();
    bool redoEdit();
    bool canUndo() const { return !undoStack.empty(); }
    bool canRedo() const { return !redoStack.empty(); }

private:
    std::vector<Snapshot> undoStack, redoStack;
    std::array<std::array<juce::dsp::IIR::Filter<float>, 2>, bandCount> filters;
    std::array<std::array<float, 5>, bandCount> lastParams {};
    juce::AudioBuffer<float> dryBuffer;
    juce::dsp::FFT fft { fftOrder };
    juce::dsp::WindowingFunction<float> window { fftSize, juce::dsp::WindowingFunction<float>::hann };
    std::array<float, fftSize> fftFifo {};
    std::array<float, fftSize * 2> fftData {};
    std::array<float, fftSize / 2> spectrum {};
    std::atomic<bool> spectrumReady { false };
    int fftIndex = 0;
    double currentSampleRate = 44100.0;
    void updateFilters();
    void pushSample(float sample);
    static Coeff::Ptr coefficients(float freq, float q, float gain, int type, double sr);
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(NovaEQAudioProcessor)
};
