#include "PluginProcessor.h"
#include "PluginEditor.h"
#include <cmath>

NovaEQAudioProcessor::NovaEQAudioProcessor()
 : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
                                   .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
   parameters(*this, nullptr, "PARAMS", createLayout()) {}

juce::AudioProcessorValueTreeState::ParameterLayout NovaEQAudioProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout p;
    constexpr std::array<float, bandCount> freqs { 35.f, 110.f, 300.f, 750.f, 1800.f, 4200.f, 9500.f, 16000.f };
    for (int i = 0; i < bandCount; ++i)
    {
        const auto prefix = "Band " + juce::String(i + 1) + " ";
        p.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID { id(i, "on"), 1 }, prefix + "Enabled", i == 0 || i == 7 ? false : true));
        p.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { id(i, "freq"), 1 }, prefix + "Frequency", juce::NormalisableRange<float>(20.f, 20000.f, 0.f, 0.25f), freqs[(size_t)i]));
        p.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { id(i, "gain"), 1 }, prefix + "Gain", juce::NormalisableRange<float>(-24.f, 24.f, 0.1f), 0.f));
        p.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { id(i, "q"), 1 }, prefix + "Q", juce::NormalisableRange<float>(0.15f, 18.f, 0.f, 0.35f), 0.9f));
        p.add(std::make_unique<juce::AudioParameterChoice>(juce::ParameterID { id(i, "type"), 1 }, prefix + "Type",
                 juce::StringArray { "Bell", "Low Shelf", "High Shelf", "Low Cut", "High Cut", "Notch" },
                 i == 0 ? 3 : (i == 7 ? 4 : 0)));
    }
    p.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { "output", 1 }, "Output Gain", -24.f, 24.f, 0.f));
    p.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID { "mix", 1 }, "Mix", 0.f, 100.f, 100.f));
    p.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID { "bypass", 1 }, "Bypass", false));
    return p;
}

bool NovaEQAudioProcessor::isBusesLayoutSupported(const BusesLayout& b) const
{
    const auto& main = b.getMainOutputChannelSet();
    return (main == juce::AudioChannelSet::mono() || main == juce::AudioChannelSet::stereo()) && b.getMainInputChannelSet() == main;
}

std::array<float, 5> NovaEQAudioProcessor::readBand(const NovaEQAudioProcessor& p, int i)
{
    return { p.parameters.getRawParameterValue(id(i, "on"))->load(),
             p.parameters.getRawParameterValue(id(i, "freq"))->load(),
             p.parameters.getRawParameterValue(id(i, "gain"))->load(),
             p.parameters.getRawParameterValue(id(i, "q"))->load(),
             p.parameters.getRawParameterValue(id(i, "type"))->load() };
}

NovaEQAudioProcessor::Coeff::Ptr NovaEQAudioProcessor::coefficients(float freq, float q, float gain, int type, double sr)
{
    const auto hz = juce::jlimit(20.f, (float)(sr * 0.49), freq);
    const auto qq = juce::jlimit(0.15f, 18.f, q);
    const auto linear = juce::Decibels::decibelsToGain(gain);
    switch (type)
    {
        case 1: return Coeff::makeLowShelf(sr, hz, qq, linear);
        case 2: return Coeff::makeHighShelf(sr, hz, qq, linear);
        case 3: return Coeff::makeHighPass(sr, hz, qq);
        case 4: return Coeff::makeLowPass(sr, hz, qq);
        case 5: return Coeff::makeNotch(sr, hz, qq);
        default: return Coeff::makePeakFilter(sr, hz, qq, linear);
    }
}

double NovaEQAudioProcessor::magnitudeAt(float freq, double sr, const std::array<float, 5>& b)
{
    if (b[0] < 0.5f) return 1.0;
    const auto co = coefficients(b[1], b[3], b[2], (int)b[4], sr);
    return co->getMagnitudeForFrequency(juce::jlimit(1.0, sr * 0.49, (double)freq), sr);
}

void NovaEQAudioProcessor::prepareToPlay(double sr, int blockSize)
{
    currentSampleRate = sr;
    dryBuffer.setSize(2, juce::jmax(128, blockSize));
    for (auto& band : filters)
        for (auto& filter : band) filter.reset();
    for (auto& b : lastParams) b.fill(-99999.f);
    fftIndex = 0;
    spectrumReady.store(false);
    updateFilters();
}

void NovaEQAudioProcessor::updateFilters()
{
    for (int i = 0; i < bandCount; ++i)
    {
        auto b = readBand(*this, i);
        if (b == lastParams[(size_t)i]) continue;
        auto co = coefficients(b[1], b[3], b[2], (int)b[4], currentSampleRate);
        for (auto& filter : filters[(size_t)i]) *filter.coefficients = *co;
        lastParams[(size_t)i] = b;
    }
}

void NovaEQAudioProcessor::pushSample(float x)
{
    fftFifo[(size_t)fftIndex++] = x;
    if (fftIndex != fftSize) return;
    fftIndex = 0;
    // The audio thread never blocks on the display: skip analysis if the last frame isn't consumed.
    if (spectrumReady.load(std::memory_order_acquire)) return;
    std::copy(fftFifo.begin(), fftFifo.end(), fftData.begin());
    std::fill(fftData.begin() + fftSize, fftData.end(), 0.f);
    window.multiplyWithWindowingTable(fftData.data(), fftSize);
    fft.performFrequencyOnlyForwardTransform(fftData.data());
    for (int i = 0; i < fftSize / 2; ++i)
        spectrum[(size_t)i] = fftData[(size_t)i] / (float)fftSize;
    spectrumReady.store(true, std::memory_order_release);
}

bool NovaEQAudioProcessor::fetchSpectrum(std::array<float, fftSize / 2>& out)
{
    if (!spectrumReady.load(std::memory_order_acquire)) return false;
    out = spectrum;
    spectrumReady.store(false, std::memory_order_release);
    return true;
}

void NovaEQAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int channels = buffer.getNumChannels();
    const int samples = buffer.getNumSamples();
    if (channels == 0) return;
    const bool bypass = parameters.getRawParameterValue("bypass")->load() > 0.5f;
    const float mix = parameters.getRawParameterValue("mix")->load() * 0.01f;
    const float outGain = juce::Decibels::decibelsToGain(parameters.getRawParameterValue("output")->load());
    updateFilters();
    // Sample-level processing avoids temporary heap allocation inside the audio callback.
    for (int s = 0; s < samples; ++s)
    {
        float analyzerSample = 0.f;
        for (int ch = 0; ch < channels; ++ch)
        {
            const float input = buffer.getSample(ch, s);
            float processed = input;
            if (!bypass)
            {
                for (int i = 0; i < bandCount; ++i)
                    if (lastParams[(size_t)i][0] > 0.5f)
                        processed = filters[(size_t)i][(size_t)ch].processSample(processed);
                processed = (input + (processed - input) * mix) * outGain;
            }
            buffer.setSample(ch, s, processed);
            analyzerSample += processed / (float)channels;
        }
        pushSample(analyzerSample);
    }
}

NovaEQAudioProcessor::Snapshot NovaEQAudioProcessor::captureSnapshot() const
{
    Snapshot result {};
    int index = 0;
    for (int b = 0; b < bandCount; ++b)
        for (auto* suffix : { "on", "freq", "gain", "q", "type" })
            result[(size_t)index++] = parameters.getRawParameterValue(id(b, suffix))->load();
    for (auto* name : { "output", "mix", "bypass" })
        result[(size_t)index++] = parameters.getRawParameterValue(name)->load();
    return result;
}

void NovaEQAudioProcessor::applySnapshot(const Snapshot& snapshot)
{
    int index = 0;
    auto set = [this, &snapshot, &index](const juce::String& name)
    {
        if (auto* param = parameters.getParameter(name))
        {
            const auto wanted = snapshot[(size_t)index];
            if (std::abs(parameters.getRawParameterValue(name)->load() - wanted) > 0.0001f)
            {
                param->beginChangeGesture();
                param->setValueNotifyingHost(param->convertTo0to1(wanted));
                param->endChangeGesture();
            }
        }
        ++index;
    };
    for (int b = 0; b < bandCount; ++b)
        for (auto* suffix : { "on", "freq", "gain", "q", "type" }) set(id(b, suffix));
    for (auto* name : { "output", "mix", "bypass" }) set(name);
}

void NovaEQAudioProcessor::recordEdit(const Snapshot& before)
{
    if (before == captureSnapshot()) return;
    undoStack.push_back(before);
    if (undoStack.size() > 100) undoStack.erase(undoStack.begin());
    redoStack.clear();
}

bool NovaEQAudioProcessor::undoEdit()
{
    if (undoStack.empty()) return false;
    const auto previous = undoStack.back();
    undoStack.pop_back();
    redoStack.push_back(captureSnapshot());
    applySnapshot(previous);
    return true;
}

bool NovaEQAudioProcessor::redoEdit()
{
    if (redoStack.empty()) return false;
    const auto next = redoStack.back();
    redoStack.pop_back();
    undoStack.push_back(captureSnapshot());
    applySnapshot(next);
    return true;
}

void NovaEQAudioProcessor::getStateInformation(juce::MemoryBlock& data)
{
    if (auto xml = parameters.copyState().createXml()) copyXmlToBinary(*xml, data);
}
void NovaEQAudioProcessor::setStateInformation(const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data, size))
        if (xml->hasTagName(parameters.state.getType())) parameters.replaceState(juce::ValueTree::fromXml(*xml));
}
juce::AudioProcessorEditor* NovaEQAudioProcessor::createEditor()
{
    return new NovaEQAudioProcessorEditor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new NovaEQAudioProcessor(); }
