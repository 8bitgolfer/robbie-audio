#include "PluginEditor.h"
#include <cmath>

namespace {
constexpr float kLeft = 56.f, kRight = 28.f, kTop = 88.f, kBottom = 198.f;
constexpr float minF = 20.f, maxF = 20000.f;
const juce::Colour bg(0xff111419), topBar(0xff181d24), panel(0xff171c23), panel2(0xff1d232c), panelStroke(0xff2b323d),
                   muted(0xff91a0b2), white(0xffedf2f8), accent(0xff4ec4f3), zeroLine(0xff647286),
                   buttonGrey(0xff232a34), offGrey(0xff2b333f), meterBlue(0xff67d2ff);
void writeParameter(juce::AudioProcessorValueTreeState& state, const juce::String& id, float v)
{
    if (auto* p = state.getParameter(id))
    {
        p->beginChangeGesture();
        p->setValueNotifyingHost(p->convertTo0to1(v));
        p->endChangeGesture();
    }
}
static juce::String fmtFreq(float hz)
{
    if (hz >= 1000.f)
        return juce::String(hz / 1000.f, hz >= 10000.f ? 1 : 2) + " kHz";
    return juce::String((int)std::round(hz)) + " Hz";
}
}

NovaEQAudioProcessorEditor::NovaEQAudioProcessorEditor(NovaEQAudioProcessor& p)
  : AudioProcessorEditor(&p), processor(p)
{
    setSize(1040, 650);
    setResizable(true, true);
    setResizeLimits(860, 560, 1560, 1000);
    for (auto* slider : { &frequency, &gain, &quality, &output, &mix })
    {
        addAndMakeVisible(*slider);
        slider->setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        slider->setTextBoxStyle(juce::Slider::TextBoxBelow, false, 92, 22);
        slider->setColour(juce::Slider::rotarySliderFillColourId, accent);
        slider->setColour(juce::Slider::rotarySliderOutlineColourId, juce::Colour(0xff324050));
        slider->setColour(juce::Slider::thumbColourId, white);
        slider->setColour(juce::Slider::textBoxTextColourId, white);
        slider->setColour(juce::Slider::textBoxBackgroundColourId, panel2);
        slider->setColour(juce::Slider::textBoxOutlineColourId, panelStroke);
    }

    frequency.setRange(20, 20000, 1);
    frequency.setSkewFactorFromMidPoint(1000);
    frequency.setTextValueSuffix(" Hz");
    gain.setRange(-24, 24, 0.1); gain.setTextValueSuffix(" dB");
    quality.setRange(0.15, 18, 0.01);
    output.setRange(-24, 24, 0.1); output.setTextValueSuffix(" dB");
    mix.setRange(0, 100, 1); mix.setTextValueSuffix(" %");

    setupKnob(frequency, freqLabel, "FREQUENCY");
    setupKnob(gain, gainLabel, "GAIN");
    setupKnob(quality, qLabel, "Q / WIDTH");
    setupKnob(output, outLabel, "OUTPUT");
    setupKnob(mix, mixLabel, "MIX");

    for (int i = 0; i < 6; ++i)
        filterType.addItem(juce::StringArray { "Bell", "Low Shelf", "High Shelf", "Low Cut", "High Cut", "Notch" }[i], i + 1);
    addAndMakeVisible(filterType);
    filterType.setColour(juce::ComboBox::backgroundColourId, panel2);
    filterType.setColour(juce::ComboBox::outlineColourId, panelStroke);
    filterType.setColour(juce::ComboBox::textColourId, white);
    filterType.setColour(juce::ComboBox::arrowColourId, muted);

    addAndMakeVisible(typeLabel);
    typeLabel.setText("FILTER TYPE", juce::dontSendNotification);
    typeLabel.setColour(juce::Label::textColourId, muted);
    typeLabel.setJustificationType(juce::Justification::centred);

    for (auto* b : { &enabled, &bypass, &reset })
    {
        addAndMakeVisible(*b);
        b->setColour(juce::TextButton::buttonColourId, buttonGrey);
        b->setColour(juce::TextButton::buttonOnColourId, accent.darker(0.3f));
        b->setColour(juce::TextButton::textColourOffId, white);
        b->setColour(juce::TextButton::textColourOnId, white);
    }

    for (auto* b : { &presetButton, &saveButton, &undoButton, &redoButton })
    {
        addAndMakeVisible(*b);
        b->setColour(juce::TextButton::buttonColourId, buttonGrey);
        b->setColour(juce::TextButton::textColourOffId, white);
    }
    presetButton.onClick = [this] { showPresetsMenu(); };
    saveButton.onClick = [this] { savePresetDialog(); };
    undoButton.onClick = [this] { runUndo(); };
    redoButton.onClick = [this] { runRedo(); };

    for (auto* s : { &frequency, &gain, &quality, &output, &mix })
    {
        s->onDragStart = [this] { beginEdit(); };
        s->onDragEnd = [this] { finishEdit(); };
    }

    frequency.onValueChange = [this] { if (!dragging) writeParam(NovaEQAudioProcessor::id(selected, "freq"), (float)frequency.getValue()); };
    gain.onValueChange = [this] { if (!dragging) writeParam(NovaEQAudioProcessor::id(selected, "gain"), (float)gain.getValue()); };
    quality.onValueChange = [this] { writeParam(NovaEQAudioProcessor::id(selected, "q"), (float)quality.getValue()); };
    output.onValueChange = [this] { writeParam("output", (float)output.getValue()); };
    mix.onValueChange = [this] { writeParam("mix", (float)mix.getValue()); };
    filterType.onChange = [this]
    {
        writeParam(NovaEQAudioProcessor::id(selected, "type"), (float)(filterType.getSelectedId() - 1));
        repaint();
    };
    enabled.onClick = [this]
    {
        auto v = NovaEQAudioProcessor::readBand(processor, selected);
        writeParam(NovaEQAudioProcessor::id(selected, "on"), v[0] > 0.5f ? 0.f : 1.f);
        syncControls(); repaint();
    };
    bypass.onClick = [this]
    {
        const auto v = processor.parameters.getRawParameterValue("bypass")->load();
        writeParam("bypass", v > 0.5f ? 0.f : 1.f);
        syncControls(); repaint();
    };
    reset.onClick = [this] { performTrackedAction([this] { resetAll(); }); activePreset = "Default"; };

    enabled.setButtonText("ON");
    bypass.setButtonText("BYPASS");
    reset.setButtonText("RESET ALL");

    setWantsKeyboardFocus(true);
    selectBand(3);
    undoButton.setEnabled(processor.canUndo());
    redoButton.setEnabled(processor.canRedo());
    startTimerHz(30);
}

void NovaEQAudioProcessorEditor::setupKnob(juce::Slider&, juce::Label& label, const juce::String& title)
{
    addAndMakeVisible(label);
    label.setText(title, juce::dontSendNotification);
    label.setColour(juce::Label::textColourId, muted);
    label.setJustificationType(juce::Justification::centred);
    label.setFont(juce::FontOptions(11.f, juce::Font::bold));
}

void NovaEQAudioProcessorEditor::beginEdit()
{
    if (editActive) return;
    editBefore = processor.captureSnapshot();
    editActive = true;
}

void NovaEQAudioProcessorEditor::finishEdit()
{
    if (!editActive) return;
    processor.recordEdit(editBefore);
    editActive = false;
    undoButton.setEnabled(processor.canUndo());
    redoButton.setEnabled(processor.canRedo());
}

void NovaEQAudioProcessorEditor::performTrackedAction(const std::function<void()>& fn)
{
    const bool own = !editActive;
    if (own) beginEdit();
    fn();
    if (own) finishEdit();
}

void NovaEQAudioProcessorEditor::writeParam(const juce::String& id, float v)
{
    performTrackedAction([this, &id, v] { writeParameter(processor.parameters, id, v); });
    repaint();
}

void NovaEQAudioProcessorEditor::runUndo()
{
    finishEdit();
    if (processor.undoEdit()) { activePreset = "Custom"; syncControls(); repaint(); }
    undoButton.setEnabled(processor.canUndo());
    redoButton.setEnabled(processor.canRedo());
}

void NovaEQAudioProcessorEditor::runRedo()
{
    finishEdit();
    if (processor.redoEdit()) { activePreset = "Custom"; syncControls(); repaint(); }
    undoButton.setEnabled(processor.canUndo());
    redoButton.setEnabled(processor.canRedo());
}

void NovaEQAudioProcessorEditor::selectBand(int b)
{
    selected = juce::jlimit(0, 7, b);
    syncControls();
    repaint();
}

void NovaEQAudioProcessorEditor::syncControls()
{
    auto b = NovaEQAudioProcessor::readBand(processor, selected);
    frequency.setValue(b[1], juce::dontSendNotification);
    gain.setValue(b[2], juce::dontSendNotification);
    quality.setValue(b[3], juce::dontSendNotification);
    filterType.setSelectedId((int)b[4] + 1, juce::dontSendNotification);
    enabled.setButtonText(b[0] > 0.5f ? "ON" : "OFF");
    enabled.setColour(juce::TextButton::buttonColourId, b[0] > 0.5f ? colours[(size_t)selected].withAlpha(0.50f) : offGrey);
    const bool by = processor.parameters.getRawParameterValue("bypass")->load() > 0.5f;
    bypass.setButtonText(by ? "BYPASSED" : "BYPASS");
    bypass.setColour(juce::TextButton::buttonColourId, by ? juce::Colour(0xff74434a) : buttonGrey);
    output.setValue(processor.parameters.getRawParameterValue("output")->load(), juce::dontSendNotification);
    mix.setValue(processor.parameters.getRawParameterValue("mix")->load(), juce::dontSendNotification);
}

void NovaEQAudioProcessorEditor::resetAll()
{
    const std::array<float, 8> defaults { 35.f, 110.f, 300.f, 750.f, 1800.f, 4200.f, 9500.f, 16000.f };
    for (int i = 0; i < 8; ++i)
    {
        writeParam(NovaEQAudioProcessor::id(i, "on"), (i == 0 || i == 7) ? 0.f : 1.f);
        writeParam(NovaEQAudioProcessor::id(i, "freq"), defaults[(size_t)i]);
        writeParam(NovaEQAudioProcessor::id(i, "gain"), 0.f);
        writeParam(NovaEQAudioProcessor::id(i, "q"), 0.9f);
        writeParam(NovaEQAudioProcessor::id(i, "type"), i == 0 ? 3.f : (i == 7 ? 4.f : 0.f));
    }
    writeParam("output", 0.f); writeParam("mix", 100.f); writeParam("bypass", 0.f);
    syncControls(); repaint();
}

void NovaEQAudioProcessorEditor::resetBand(int band)
{
    if (!juce::isPositiveAndBelow(band, 8)) return;
    performTrackedAction([this, band]
    {
        for (const auto* suffix : { "on", "freq", "gain", "q", "type" })
        {
            if (auto* param = processor.parameters.getParameter(NovaEQAudioProcessor::id(band, suffix)))
            {
                param->beginChangeGesture();
                param->setValueNotifyingHost(param->getDefaultValue());
                param->endChangeGesture();
            }
        }
    });
    activePreset = "Custom";
    selectBand(band);
}

void NovaEQAudioProcessorEditor::showBandMenu(int band)
{
    if (!juce::isPositiveAndBelow(band, 8)) return;
    const auto values = NovaEQAudioProcessor::readBand(processor, band);
    juce::PopupMenu menu;
    menu.addSectionHeader("Band " + juce::String(band + 1));
    menu.addItem(1, "Reset");
    menu.addSeparator();
    menu.addItem(2, "Enabled", true, values[0] > 0.5f);
    juce::PopupMenu types;
    const juce::StringArray names { "Bell", "Low Shelf", "High Shelf", "Low Cut", "High Cut", "Notch" };
    for (int i = 0; i < names.size(); ++i)
        types.addItem(100 + i, names[i], true, (int)values[4] == i);
    menu.addSubMenu("Type", types);

    juce::Component::SafePointer<NovaEQAudioProcessorEditor> safeThis(this);
    menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(this),
        [safeThis, band](int result)
        {
            if (safeThis == nullptr) return;
            if (result == 1) safeThis->resetBand(band);
            else if (result == 2)
            {
                const auto v = NovaEQAudioProcessor::readBand(safeThis->processor, band);
                safeThis->writeParam(NovaEQAudioProcessor::id(band, "on"), v[0] > 0.5f ? 0.f : 1.f);
                safeThis->selectBand(band);
            }
            else if (result >= 100 && result < 106)
            {
                safeThis->writeParam(NovaEQAudioProcessor::id(band, "type"), (float)(result - 100));
                safeThis->selectBand(band);
            }
        });
}

namespace {
// The default preset is the unchanged starting EQ. These are starting points,
// not claims that one curve works for every voice or instrument.
struct BandPreset { float freq, gain, q; int type; bool on; };
using Bank = std::array<BandPreset, 8>;
Bank makeBase()
{
    return {{{35, 0, .9f, 3, false}, {110, 0, .9f, 0, true},
             {300, 0, .9f, 0, true}, {750, 0, .9f, 0, true},
             {1800, 0, .9f, 0, true}, {4200, 0, .9f, 0, true},
             {9500, 0, .9f, 0, true}, {16000, 0, .9f, 4, false}}};
}
const juce::StringArray factoryNames { "Default / Flat", "Vocal Clarity", "Warm Vocals", "Airy Vocals",
    "Rap Presence", "Deep Bass", "Tight Low End", "Brighten", "Remove Mud",
    "Telephone", "Gentle Master", "Lo-Fi" };
Bank factoryBank(int preset)
{
    Bank b = makeBase();
    auto put = [&b](int i, float f, float g, float q, int type, bool on = true)
    { b[(size_t)i] = { f, g, q, type, on }; };
    switch (preset)
    {
        case 1: put(0, 85, 0, .71f, 3); put(1, 180, -1.5f, .9f, 0); put(2, 320, -2.5f, 1.2f, 0);
                put(4, 2800, 2.0f, .8f, 0); put(5, 5200, 1.5f, .9f, 0); put(6, 11500, 1.8f, .7f, 2); break;
        case 2: put(0, 70, 0, .71f, 3); put(1, 210, 1.5f, .9f, 0); put(2, 480, -1.2f, 1.0f, 0);
                put(4, 2750, 1.1f, .9f, 0); put(6, 10000, -1.0f, .7f, 2); break;
        case 3: put(0, 85, 0, .71f, 3); put(2, 350, -1.8f, 1.0f, 0); put(4, 3300, 1.5f, .9f, 0);
                put(6, 11000, 3.2f, .7f, 2); break;
        case 4: put(0, 90, 0, .71f, 3); put(2, 330, -2.0f, 1.1f, 0); put(4, 2500, 2.2f, 1.0f, 0);
                put(5, 4700, 1.2f, 1.0f, 0); put(6, 9000, 1.0f, .8f, 2); break;
        case 5: put(1, 75, 3.2f, .7f, 1); put(2, 260, -1.5f, 1.1f, 0); put(3, 600, -.8f, .9f, 0);
                put(5, 4000, .7f, 1.0f, 0); break;
        case 6: put(0, 35, 0, .71f, 3); put(1, 130, -1.5f, .7f, 0);
                put(2, 320, -2.5f, 1.0f, 0); put(4, 1800, 1.0f, .8f, 0); break;
        case 7: put(4, 2800, 1.5f, .8f, 0); put(6, 9500, 2.5f, .7f, 2); break;
        case 8: put(2, 300, -3.5f, 1.0f, 0); put(3, 600, -1.2f, 1.0f, 0); break;
        case 9: put(0, 400, 0, .71f, 3); put(7, 3500, 0, .71f, 4); break;
        case 10: put(1, 95, .9f, .7f, 1); put(2, 350, -.7f, .9f, 0);
                 put(4, 3500, .7f, .7f, 0); put(6, 12500, 1.0f, .7f, 2); break;
        case 11: put(0, 160, 0, .71f, 3); put(2, 600, -1.5f, 1.f, 0);
                 put(6, 7400, -2.0f, .7f, 2); put(7, 9500, 0, .71f, 4); break;
        default: break;
    }
    return b;
}
}

void NovaEQAudioProcessorEditor::applyFactoryPreset(int index)
{
    if (!juce::isPositiveAndBelow(index, factoryNames.size())) return;
    const auto b = factoryBank(index);
    performTrackedAction([this, &b]
    {
        for (int i = 0; i < 8; ++i)
        {
            const auto& x = b[(size_t)i];
            writeParam(NovaEQAudioProcessor::id(i, "freq"), x.freq);
            writeParam(NovaEQAudioProcessor::id(i, "gain"), x.gain);
            writeParam(NovaEQAudioProcessor::id(i, "q"), x.q);
            writeParam(NovaEQAudioProcessor::id(i, "type"), (float)x.type);
            writeParam(NovaEQAudioProcessor::id(i, "on"), x.on ? 1.f : 0.f);
        }
        writeParam("output", 0.f);
        writeParam("mix", 100.f);
        writeParam("bypass", 0.f);
    });
    activePreset = factoryNames[index];
    syncControls(); repaint();
}

juce::File NovaEQAudioProcessorEditor::presetDirectory() const
{
    return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
            .getChildFile("Robbie").getChildFile("EQ").getChildFile("Presets");
}

bool NovaEQAudioProcessorEditor::savePresetToFile(const juce::File& file)
{
    juce::XmlElement root("RobbieEQPreset");
    root.setAttribute("version", 1);
    root.setAttribute("name", file.getFileNameWithoutExtension());
    auto snapshot = processor.captureSnapshot();
    for (int i = 0; i < NovaEQAudioProcessor::parameterCount; ++i)
        root.setAttribute("p" + juce::String(i), (double)snapshot[(size_t)i]);
    if (file.getParentDirectory().createDirectory().failed()) return false;
    const bool ok = root.writeTo(file);
    if (ok) { activePreset = file.getFileNameWithoutExtension(); repaint(); }
    return ok;
}

bool NovaEQAudioProcessorEditor::loadPresetFromFile(const juce::File& file)
{
    auto xml = juce::XmlDocument::parse(file);
    if (xml == nullptr || !xml->hasTagName("RobbieEQPreset") || xml->getIntAttribute("version") != 1)
        return false;
    auto values = processor.captureSnapshot();
    for (int i = 0; i < NovaEQAudioProcessor::parameterCount; ++i)
    {
        const auto key = "p" + juce::String(i);
        if (!xml->hasAttribute(key)) return false;
        const auto v = xml->getDoubleAttribute(key);
        if (!std::isfinite(v)) return false;
        values[(size_t)i] = (float)v;
    }
    performTrackedAction([this, &values] { processor.applySnapshot(values); });
    activePreset = file.getFileNameWithoutExtension();
    syncControls(); repaint();
    return true;
}

void NovaEQAudioProcessorEditor::savePresetDialog()
{
    auto dir = presetDirectory();
    dir.createDirectory();
    presetChooser = std::make_unique<juce::FileChooser>("Save EQ preset", dir.getChildFile("My Preset.rbeq"), "*.rbeq");
    juce::Component::SafePointer<NovaEQAudioProcessorEditor> safeThis(this);
    presetChooser->launchAsync(juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles | juce::FileBrowserComponent::warnAboutOverwriting,
        [safeThis](const juce::FileChooser& chooser)
        {
            if (safeThis == nullptr) return;
            auto file = chooser.getResult();
            if (file == juce::File()) return;
            file = file.withFileExtension(".rbeq");
            if (!safeThis->savePresetToFile(file))
                juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon, "Save failed", "Could not save this preset.");
        });
}

void NovaEQAudioProcessorEditor::importPresetDialog()
{
    presetChooser = std::make_unique<juce::FileChooser>("Import EQ preset", presetDirectory(), "*.rbeq");
    juce::Component::SafePointer<NovaEQAudioProcessorEditor> safeThis(this);
    presetChooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [safeThis](const juce::FileChooser& chooser)
        {
            if (safeThis == nullptr) return;
            const auto file = chooser.getResult();
            if (file == juce::File()) return;
            if (!safeThis->loadPresetFromFile(file))
                juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon, "Load failed", "Not a valid EQ preset.");
        });
}

void NovaEQAudioProcessorEditor::showPresetsMenu()
{
    juce::PopupMenu menu;
    juce::PopupMenu factory;
    for (int i = 0; i < factoryNames.size(); ++i)
        factory.addItem(100 + i, factoryNames[i], true, activePreset == factoryNames[i]);
    menu.addSubMenu("Factory presets", factory);
    juce::PopupMenu users;
    juce::Array<juce::File> userFiles;
    auto dir = presetDirectory();
    if (dir.isDirectory())
        dir.findChildFiles(userFiles, juce::File::findFiles, false, "*.rbeq");
    for (int i = 0; i < userFiles.size(); ++i)
        users.addItem(1000 + i, userFiles[i].getFileNameWithoutExtension(), true,
                      activePreset == userFiles[i].getFileNameWithoutExtension());
    if (userFiles.isEmpty()) users.addItem(9999, "No saved presets yet", false);
    menu.addSubMenu("My presets", users);
    menu.addSeparator();
    menu.addItem(1, "Save current preset...");
    menu.addItem(2, "Import preset from file...");
    menu.addItem(3, "Open preset folder");
    juce::Component::SafePointer<NovaEQAudioProcessorEditor> safeThis(this);
    menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&presetButton),
        [safeThis, userFiles](int result)
        {
            if (safeThis == nullptr) return;
            if (result >= 100 && result < 100 + factoryNames.size()) safeThis->applyFactoryPreset(result - 100);
            else if (result >= 1000 && result < 1000 + userFiles.size()) safeThis->loadPresetFromFile(userFiles[result - 1000]);
            else if (result == 1) safeThis->savePresetDialog();
            else if (result == 2) safeThis->importPresetDialog();
            else if (result == 3) { auto dir = safeThis->presetDirectory(); dir.createDirectory(); dir.startAsProcess(); }
        });
}

float NovaEQAudioProcessorEditor::freqToNorm(float f) { return std::log(juce::jlimit(minF, maxF, f) / minF) / std::log(maxF / minF); }
float NovaEQAudioProcessorEditor::normToFreq(float n) { return minF * std::pow(maxF / minF, juce::jlimit(0.f, 1.f, n)); }
float NovaEQAudioProcessorEditor::xForFreq(float f) const { return graph.getX() + freqToNorm(f) * graph.getWidth(); }
float NovaEQAudioProcessorEditor::yForGain(float db) const { return graph.getCentreY() - db * (graph.getHeight() / 48.f); }
float NovaEQAudioProcessorEditor::freqForX(float x) const { return normToFreq((x - graph.getX()) / graph.getWidth()); }
float NovaEQAudioProcessorEditor::gainForY(float y) const { return juce::jlimit(-24.f, 24.f, (graph.getCentreY() - y) * 48.f / graph.getHeight()); }

void NovaEQAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(bg);

    g.setGradientFill(juce::ColourGradient(topBar, 0.f, 0.f, bg.brighter(0.05f), 0.f, 72.f, false));
    g.fillRect(0, 0, getWidth(), 72);
    g.setColour(panelStroke.withAlpha(0.7f));
    g.drawLine(0.f, 72.f, (float)getWidth(), 72.f, 1.0f);

    g.setColour(white);
    g.setFont(juce::FontOptions(27.f, juce::Font::bold));
    g.drawText("EQ", 24, 15, 60, 34, juce::Justification::centredLeft);
    g.setColour(muted);
    g.setFont(juce::FontOptions(12.5f));
    g.drawText("8-band parametric equalizer", 82, 22, 212, 22, juce::Justification::centredLeft);
    g.drawText("Robbie", 24, 41, 80, 18, juce::Justification::centredLeft);

    auto band = NovaEQAudioProcessor::readBand(processor, selected);
    const juce::StringArray typeNames { "Bell", "Low Shelf", "High Shelf", "Low Cut", "High Cut", "Notch" };
    juce::String readout = "Band " + juce::String(selected + 1) + "   " + typeNames[(int)juce::jlimit(0, 5, (int)band[4])] +
                           "   " + fmtFreq(band[1]) + "   " + juce::String(band[2], 1) + " dB   Q " + juce::String(band[3], 2);
    g.setColour(white.withAlpha(0.85f));
    g.setFont(juce::FontOptions(11.f, juce::Font::plain));
    g.drawFittedText(readout, 300, 51, getWidth() - 330, 18, juce::Justification::centredRight, 1);
    g.setColour(muted);
    g.drawFittedText("PRESET  /  " + activePreset, 300, 13, 215, 20, juce::Justification::centredLeft, 1);

    g.setColour(panel2);
    g.fillRoundedRectangle(graph.expanded(18.f, 12.f), 12.f);
    g.setColour(panelStroke);
    g.drawRoundedRectangle(graph.expanded(18.f, 12.f), 12.f, 1.0f);
    paintGraph(g);

    auto bottomPanel = juce::Rectangle<float>(22.f, (float)getHeight() - 172.f, (float)getWidth() - 44.f, 154.f);
    g.setColour(panel);
    g.fillRoundedRectangle(bottomPanel, 12.f);
    g.setColour(panelStroke);
    g.drawRoundedRectangle(bottomPanel, 12.f, 1.0f);

    g.setColour(muted);
    g.setFont(juce::FontOptions(11.f, juce::Font::bold));
    g.drawText("SELECTED BAND", 32, getHeight() - 164, 120, 16, juce::Justification::centredLeft);
    g.drawText("MASTER", getWidth() - 258, getHeight() - 164, 80, 16, juce::Justification::centredLeft);


    g.setColour(colours[(size_t)selected]);
    g.fillRoundedRectangle(31.f, (float)getHeight() - 147.f, 4.f, 94.f, 2.f);

    const bool bypassed = processor.parameters.getRawParameterValue("bypass")->load() > 0.5f;
    g.setColour(bypassed ? juce::Colour(0xff74434a) : juce::Colour(0xff2b333d));
    g.fillRoundedRectangle((float)getWidth() - 209.f, 24.f, 12.f, 12.f, 6.f);

    g.setColour(panelStroke.withAlpha(0.8f));
    g.drawLine((float)getWidth() - 286.f, (float)getHeight() - 160.f, (float)getWidth() - 286.f, (float)getHeight() - 28.f);
}

void NovaEQAudioProcessorEditor::paintGraph(juce::Graphics& g)
{
    g.saveState();
    g.reduceClipRegion(graph.toNearestInt());

    g.setGradientFill(juce::ColourGradient(panel, graph.getX(), graph.getY(), panel2, graph.getX(), graph.getBottom(), false));
    g.fillRect(graph);

    for (float f : { 20.f, 30.f, 40.f, 50.f, 70.f, 100.f, 200.f, 300.f, 500.f, 700.f, 1000.f, 2000.f, 3000.f, 5000.f, 7000.f, 10000.f, 20000.f })
    {
        const auto x = xForFreq(f);
        const bool major = (f == 20.f || f == 50.f || f == 100.f || f == 200.f || f == 500.f || f == 1000.f || f == 2000.f || f == 5000.f || f == 10000.f || f == 20000.f);
        g.setColour(juce::Colour(major ? 0xff303947 : 0xff252d38));
        g.drawVerticalLine((int)x, graph.getY(), graph.getBottom());
    }
    for (int d = -24; d <= 24; d += 3)
    {
        const float y = yForGain((float)d);
        const bool major = (d % 6 == 0);
        g.setColour(d == 0 ? zeroLine : juce::Colour(major ? 0xff303947 : 0xff252d38));
        g.drawHorizontalLine((int)y, graph.getX(), graph.getRight());
    }

    juce::Path spectrumPath;
    bool started = false;
    for (int x = (int)graph.getX(); x <= (int)graph.getRight(); x += 2)
    {
        const float f = freqForX((float)x);
        const int bin = juce::jlimit(1, NovaEQAudioProcessor::fftSize / 2 - 1,
                          (int)(f * NovaEQAudioProcessor::fftSize / juce::jmax(1., processor.getSampleRate())));
        float peak = 0.f;
        for (int j = juce::jmax(1, bin - 2); j <= juce::jmin(NovaEQAudioProcessor::fftSize / 2 - 1, bin + 2); ++j)
            peak = juce::jmax(peak, smoothSpectrum[(size_t)j]);
        float db = juce::Decibels::gainToDecibels(peak, -90.f);
        float y = juce::jmap(juce::jlimit(-90.f, 0.f, db), -90.f, 0.f, graph.getBottom() - 4.f, graph.getY() + 4.f);
        if (!started) { spectrumPath.startNewSubPath((float)x, y); started = true; }
        else spectrumPath.lineTo((float)x, y);
    }
    g.setColour(meterBlue.withAlpha(0.15f));
    g.strokePath(spectrumPath, juce::PathStrokeType(1.15f));

    juce::Path eqPath; bool first = true;
    const auto sr = juce::jmax(44100.0, processor.getSampleRate());
    for (int x = (int)graph.getX(); x <= (int)graph.getRight(); x += 2)
    {
        const float f = freqForX((float)x);
        double mag = 1.;
        for (int i = 0; i < 8; ++i) mag *= NovaEQAudioProcessor::magnitudeAt(f, sr, NovaEQAudioProcessor::readBand(processor, i));
        const float y = juce::jlimit(graph.getY() + 2.f, graph.getBottom() - 2.f,
                        yForGain(juce::Decibels::gainToDecibels((float)mag, -100.f)));
        if (first) { eqPath.startNewSubPath((float)x, y); first = false; }
        else eqPath.lineTo((float)x, y);
    }
    g.setColour(accent.withAlpha(0.12f));
    juce::Path fill(eqPath); fill.lineTo(graph.getRight(), yForGain(0)); fill.lineTo(graph.getX(), yForGain(0)); fill.closeSubPath();
    g.fillPath(fill);
    g.setColour(accent);
    g.strokePath(eqPath, juce::PathStrokeType(2.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    for (int i = 0; i < 8; ++i)
    {
        auto b = NovaEQAudioProcessor::readBand(processor, i);
        float x = xForFreq(b[1]);
        float y = yForGain(((int)b[4] == 3 || (int)b[4] == 4 || (int)b[4] == 5) ? 0.f : b[2]);
        y = juce::jlimit(graph.getY() + 12.f, graph.getBottom() - 12.f, y);
        auto c = colours[(size_t)i];
        if (b[0] < 0.5f) c = c.withAlpha(0.38f);
        if (i == selected)
        {
            g.setColour(c.withAlpha(0.16f));
            g.fillEllipse(x - 17.f, y - 17.f, 34.f, 34.f);
        }
        g.setColour(c.withAlpha(0.22f));
        g.fillEllipse(x - 11.5f, y - 11.5f, 23.f, 23.f);
        g.setColour(c);
        g.drawEllipse(x - 9.f, y - 9.f, 18.f, 18.f, 2.0f);
        g.setColour(white);
        g.fillEllipse(x - 2.6f, y - 2.6f, 5.2f, 5.2f);
        g.setFont(juce::FontOptions(9.5f, juce::Font::bold));
        g.setColour(white.withAlpha(0.85f));
        g.drawText(juce::String(i + 1), (int)x - 10, (int)y - 28, 20, 12, juce::Justification::centred);
    }
    g.restoreState();

    g.setFont(juce::FontOptions(10.f));
    g.setColour(muted);
    for (int db = -24; db <= 24; db += 6)
        g.drawText((db > 0 ? "+" : "") + juce::String(db), 10, (int)yForGain((float)db) - 8, 38, 17, juce::Justification::centredRight);

    for (float f : { 20.f, 50.f, 100.f, 200.f, 500.f, 1000.f, 2000.f, 5000.f, 10000.f, 20000.f })
    {
        const auto x = xForFreq(f);
        const juce::String t = f >= 1000.f ? juce::String(f / 1000.f, 0) + "k" : juce::String((int)f);
        g.drawText(t, (int)x - 16, (int)graph.getBottom() - 18, 32, 14, juce::Justification::centred);
    }
}

void NovaEQAudioProcessorEditor::resized()
{
    graph = { kLeft, kTop, (float)getWidth() - kLeft - kRight, (float)getHeight() - kTop - kBottom };
    const int y = getHeight() - 136;
    const int usable = getWidth() - 330;
    const int step = usable / 5;
    auto position = [y](juce::Slider& s, juce::Label& l, int x, int w)
    {
        l.setBounds(x, y - 16, w, 18);
        s.setBounds(x, y + 8, w, 108);
    };
    position(frequency, freqLabel, 46, step);
    position(gain, gainLabel, 46 + step, step);
    position(quality, qLabel, 46 + step * 2, step);
    typeLabel.setBounds(46 + step * 3, y - 16, step, 18);
    filterType.setBounds(58 + step * 3, y + 46, step - 10, 30);
    enabled.setBounds(54 + step * 4, y + 43, step - 10, 34);
    const int rightStart = getWidth() - 278;
    position(output, outLabel, rightStart + 9, 102);
    position(mix, mixLabel, rightStart + 114, 102);
    bypass.setBounds(getWidth() - 98, 17, 83, 29);
    redoButton.setBounds(getWidth() - 176, 17, 70, 29);
    undoButton.setBounds(getWidth() - 254, 17, 70, 29);
    saveButton.setBounds(getWidth() - 322, 17, 60, 29);
    presetButton.setBounds(getWidth() - 418, 17, 88, 29);
    reset.setBounds(getWidth() - 522, 17, 96, 29);
}

bool NovaEQAudioProcessorEditor::keyPressed(const juce::KeyPress& key)
{
    if (key.getModifiers().isCommandDown() && key.getKeyCode() == 'z')
    {
        if (key.getModifiers().isShiftDown()) runRedo(); else runUndo();
        return true;
    }
    if (key.getModifiers().isCommandDown() && key.getKeyCode() == 'y')
    {
        runRedo();
        return true;
    }
    return juce::AudioProcessorEditor::keyPressed(key);
}

void NovaEQAudioProcessorEditor::mouseDown(const juce::MouseEvent& e)
{
    if (!graph.contains(e.position)) return;
    int found = -1;
    float best = 22.f * 22.f;
    for (int i = 0; i < 8; ++i)
    {
        auto b = NovaEQAudioProcessor::readBand(processor, i);
        float x = xForFreq(b[1]);
        float y = yForGain(((int)b[4] == 3 || (int)b[4] == 4 || (int)b[4] == 5) ? 0.f : b[2]);
        float d = (x - e.position.x) * (x - e.position.x) + (y - e.position.y) * (y - e.position.y);
        if (d < best) { best = d; found = i; }
    }
    if (found >= 0)
    {
        selectBand(found);
        if (e.mods.isPopupMenu())
        {
            dragging = false;
            showBandMenu(found);
        }
        else { dragging = true; beginEdit(); }
    }
    else dragging = false;
}

void NovaEQAudioProcessorEditor::mouseUp(const juce::MouseEvent&)
{
    dragging = false;
    finishEdit();
}

void NovaEQAudioProcessorEditor::mouseDrag(const juce::MouseEvent& e)
{
    if (!dragging) return;
    writeParam(NovaEQAudioProcessor::id(selected, "freq"), freqForX(e.position.x));
    auto b = NovaEQAudioProcessor::readBand(processor, selected);
    if ((int)b[4] != 3 && (int)b[4] != 4 && (int)b[4] != 5)
        writeParam(NovaEQAudioProcessor::id(selected, "gain"), gainForY(e.position.y));
    syncControls(); repaint();
}

void NovaEQAudioProcessorEditor::mouseDoubleClick(const juce::MouseEvent& e)
{
    if (!graph.contains(e.position)) return;
    mouseDown(e);
    if (dragging)
    {
        auto b = NovaEQAudioProcessor::readBand(processor, selected);
        writeParam(NovaEQAudioProcessor::id(selected, "on"), b[0] > 0.5f ? 0.f : 1.f);
        syncControls(); repaint();
    }
    dragging = false;
    finishEdit();
}

void NovaEQAudioProcessorEditor::mouseWheelMove(const juce::MouseEvent& e, const juce::MouseWheelDetails& w)
{
    if (graph.contains(e.position))
    {
        auto b = NovaEQAudioProcessor::readBand(processor, selected);
        writeParam(NovaEQAudioProcessor::id(selected, "q"), juce::jlimit(0.15f, 18.f, b[3] * std::pow(1.12f, w.deltaY * 4.f)));
        syncControls();
    }
}

void NovaEQAudioProcessorEditor::timerCallback()
{
    if (processor.fetchSpectrum(spectrum))
        for (size_t i = 0; i < spectrum.size(); ++i)
            smoothSpectrum[i] = juce::jmax(spectrum[i], smoothSpectrum[i] * 0.88f);
    else
        for (auto& x : smoothSpectrum) x *= 0.95f;
    if (!dragging) syncControls();
    repaint();
}
