@echo off
setlocal
where cmake >nul 2>&1
if errorlevel 1 (
  echo ERROR: Install CMake from https://cmake.org/download/ and add it to PATH.
  pause
  exit /b 1
)
echo Building EQ with Visual Studio 2026 C++ tools...
cmake -S . -B build -G "Visual Studio 18 2026" -A x64
if errorlevel 1 goto fail
cmake --build build --config Release --target EQ_VST3
if errorlevel 1 goto fail
echo.
echo SUCCESS. Look in build\NovaEQ_artefacts\Release\VST3\
echo Copy EQ.vst3 to C:\Program Files\Common Files\VST3\
pause
exit /b 0
:fail
echo Build failed. Check the error messages above.
pause
exit /b 1
