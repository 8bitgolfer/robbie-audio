# EQ by Robbie — v1.3

Windows VST3 source project built using JUCE and Visual Studio 2026 (CMake).

## What is new
- 12 factory presets: Default/Flat, Vocal Clarity, Warm Vocals, Airy Vocals, Rap Presence, Deep Bass, Tight Low End, Brighten, Remove Mud, Telephone, Gentle Master, Lo-Fi.
- Presets dropdown with Factory presets and My presets sections.
- Save a user preset as `.rbeq`. The default location is `%APPDATA%\Robbie\EQ\Presets`.
- Load saved presets directly from the My presets menu, or import a `.rbeq` file.
- Undo/Redo buttons with history of up to 100 edits in the current plugin instance. Graph dragging and knob dragging are grouped into one action.
- Right-click band to reset, enable/disable or change filter type.

## Build
Run `build-windows.bat` with Visual Studio 2026 C++ tools, CMake, and Git installed.
Copy `build\EQ_artefacts\Release\VST3\EQ.vst3` as a folder to `C:\Program Files\Common Files\VST3`.
Close FL Studio before copying, then rescan in Plugin Manager.

## Important details
- Factory presets are starting points and will not fit every track.
- Presets saved outside the default folder can be opened via Import, but only the default folder is listed in My presets.
- Your FL Studio projects still save plugin settings as VST3 state; user preset files are separate, reusable across projects.
- Undo/Redo is maintained by the loaded plugin instance, not persisted across plugin reloads. Changes made by FL Studio automation externally are not included in the UI undo history.
- This source package has not been built or run on Windows in this environment.
